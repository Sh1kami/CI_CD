#!/bin/sh
printf "Hello CI/CD\n"
